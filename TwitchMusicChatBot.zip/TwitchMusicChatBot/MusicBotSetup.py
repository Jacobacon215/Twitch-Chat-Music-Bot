import os
os.system('pip install twitch-listener')
os.system('pip install mutagen')
os.system('pip install ffmpeg')
os.system('pip install youtube-dl')
