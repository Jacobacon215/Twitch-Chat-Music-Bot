import os
os.system('pip import twitch-listener')
os.system('pip import mutagen')
os.system('pip import ffmpeg')
os.system('pip import youtube-dl')
