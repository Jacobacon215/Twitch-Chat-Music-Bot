from twitch_listener import listener
import os
from mutagen.mp3 import MP3
import ffmpeg
import time
config = open('twitchbotconfig.txt','r')
configtext = config.read()
tuserindex1 = configtext.find('twitch username:"')
tuserindex2 = configtext.find('"`]')
tuser = configtext[tuserindex1+17:tuserindex2]
toauthindex1 = configtext.find('oauth:"')
toauthindex2 = configtext.find('"~]')
oauth = configtext[toauthindex1+7:toauthindex2]
msdirindex1 = configtext.find('music storage directory:"')
msdirindex2 = configtext.find('"{}]')
msdir = configtext[msdirindex1+25:msdirindex2]
file = open(tuser + '.log','r+')
file.truncate(0)
file.close()
counter = 1
bot = listener.connect_twitch(tuser,
                              'oauth:' + oauth,
                              'o9lf8le4qyj1ckjmj8pd0pya1z6psc')
channels_to_listen_to = [tuser]
while 1 == 1:
    bot.listen(channels_to_listen_to, duration = 1)
    file = open(tuser + ".log","r")
    filetext = file.read()
    playtest = filetext.count("-play ") > 0
    if playtest == True:
        watchindex = int(filetext.find("watch?v=")) + 8
        watchcodeEnd = int(watchindex + 11)
        youtubeurl = "youtube.com/watch?v=" + filetext[watchindex:watchcodeEnd]
        os.system('youtube-dl -f mp4 --output ' + msdir + '\\musicfile' + str(counter) + '.mp4 "' + youtubeurl + '"')
        os.system('ffmpeg -i "' + msdir + '\\musicfile' + str(counter) + '.mp4" ' + msdir + '\\musicfile' + str(counter) + '.mp3"')
        os.system('del ' + msdir + '\\musicfile' + str(counter) + '.mp4"')
        audio = MP3(msdir + '\\musicfile' + str(counter) + '.mp3')
        audiolength = int(audio.info.length)
        os.system(msdir + '\\musicfile' + str(counter) + '.mp3"')
        time.sleep(audiolength + 5)
        os.system('del ' + msdir + '\\musicfile' + str(counter) + '.mp3"')
        os.system('taskkill /im Music.UI.exe /T /F')
        file.close()
        file = open(tuser + '.log','r+')
        file.truncate(0)
        file.close()
        counter = counter + 1
